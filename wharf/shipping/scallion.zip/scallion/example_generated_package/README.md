# Example generated package output (reference)

下面这些文件不会被本生成器运行时写出；它只是一个参考，展示 LLM 最终应该生成的目标包结构。

目标包结构：

```
greet_package/
  setup.py
  MANIFEST.in
  README.md
  LICENSE
  src/
    greet_package/
      __init__.py
  tests/
    test_greet.py
```

你实际运行生成器后，会在 `./out/<package_name>/` 看到类似结构。
