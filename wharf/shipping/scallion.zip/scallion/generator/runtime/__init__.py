"""Runtime helpers for safe filesystem writes."""
