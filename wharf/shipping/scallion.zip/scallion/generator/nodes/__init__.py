"""Graph nodes."""
