"""LangGraph package generator."""
