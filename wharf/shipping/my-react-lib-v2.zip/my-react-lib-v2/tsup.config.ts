import { defineConfig } from 'tsup';

export default defineConfig({
  entry: ['src/index.ts'],
  format: ['esm', 'cjs'],
  dts: true,
  splitting: false,
  sourcemap: true,
  clean: true,
  minify: false,
  treeshake: true,
  external: ['react', 'react-dom', 'next', 'antd'],
  esbuildOptions(options) {
    options.jsx = 'automatic';
  },
  postcss: true,
});